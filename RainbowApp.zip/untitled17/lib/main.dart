import 'package:flutter/material.dart';

void main() {
  runApp(RainbowApp());
}

class RainbowApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rainbow App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: RainbowPage(), // Start from red
    );
  }
}

class RainbowPage extends StatefulWidget {
  @override
  _RainbowPageState createState() => _RainbowPageState();
}

class _RainbowPageState extends State<RainbowPage> {
  int colorIndex = 0; // Manage colorIndex in the state

  final List<Color> rainbowColors = [
    Colors.red,
    Colors.orange,
    Colors.yellow,
    Colors.green,
    Colors.blue,
    Colors.indigo,
    Colors.purple,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Rainbow App'),
      ),
      backgroundColor: rainbowColors[colorIndex],
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: rainbowColors.length,
              itemBuilder: (BuildContext context, int index) {
                return Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Container(
                    width: 50,
                    height: 50,
                    color: rainbowColors[index],
                    child: index == colorIndex
                        ? Icon(Icons.check, color: Colors.white)
                        : null,
                  ),
                );
              },
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              setState(() {
                colorIndex = (colorIndex - 1) % rainbowColors.length;
                if (colorIndex < 0) {
                  colorIndex = rainbowColors.length - 1;
                }
              });
            },
            child: Text(
              'Previous Page',
              style: TextStyle(fontSize: 20.0),
            ),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              setState(() {
                colorIndex = (colorIndex + 1) % rainbowColors.length;
              });
            },
            child: Text(
              'Next Page',
              style: TextStyle(fontSize: 20.0),
            ),
          ),
        ],
      ),
    );
  }
}